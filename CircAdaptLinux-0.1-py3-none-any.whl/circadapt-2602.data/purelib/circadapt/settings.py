"""CircAdapt settings
Define setting parameters
"""
__author__ = 'Nick van Osta'
