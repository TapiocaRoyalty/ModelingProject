from circadapt.components import Component

class Timings(Component):
    """
    Timings for whole heart simulations.

    This module sets timings for whole heart simulations. It is designed for
    hearts with 2 artia (Chambers) and 2 ventricles (TriSeg) which results in
    five walls: Left and Rigth atrial wall and Left, septal, and right
    ventricular wall.

    Parameters
    ==========
    time_fac: float
        Relative contraction duration
    tau_av: float
        AV delay
    dtau_av: float
        Extra AV delay
    law_tau_av: int
        Tells which law is used to set tau_av at the start of each beat.
        If law_tau_av == 0, no law is used and tau_av can be set manually.
    law_Ra2La: int
        Tells which atrial delay law is used.
        If law_Ra2La == 0, no law is used.
    law_ta: int
        Tells which atrial activation duration law is used.
        If law_ta == 0, no law is used.
    law_tv: int
        Tells which ventricular activation duration law is used.
        If law_Ra2La == 0, no law is used.
    c_tau_av0: float
        Constant used to calculate tau_av depending on the used law.
    c_tau_av1
        Constant used to calculate tau_av depending on the used law.
    ta_ref: float
        Reference atrial activation duration.
    tv_ref: float
        Reference ventricular activation duration.
    """

    parameters = [
        'time_fac',
        'tau_av',
        'dtau_av',
        'law_tau_av',
        'law_Ra2La',
        'law_ta',
        'law_tv',
        'c_tau_av0',
        'c_tau_av1',
        'c_ta_rest',
        'c_ta_tcycle',
        'c_tv_rest',
        'c_tv_tcycle',
        'ta_ref',
        'tv_ref',
        ]

    signals = []


class PressureFlowControl(Component):
    """
    Pressure Flow Control by fitting ArtVen resistance and total volume.

    Parameters
    ==========
    p0 [Pa]: float
        Target pressure.
    q0 [m :sup:`3`/s]: float
        Target mean flow
    stable_threshold [-]: float
        Threshhold to determine hemodynamic stability
    is_active [-]: bool
        activates or disactivates pressure flow control
    alpha [-]: float
        Exponent to control speed.
    fac [-]: float
        Deviation from p0, driving factor for changing blood volume.
    epsilon [-]: float
        Minimal hemodynamic stability needed to allow pressure flow control.
    is_volume_control [-]: bool  
        Activates or deactivates using only volume control without pressure regulation 
    circulation_volume [m3]: float 
        Total circulation volume 
    target_volume [m3]: float 
        Target total circulation volume 
    """

    parameters = [
        'p0',
        'q0',
        'stable_threshold',
        'is_active',
        'alpha',
        'fac',
        'epsilon',
        'is_volume_control',
        'circulation_volume',
        'target_volume',
        ]

    signals = []
