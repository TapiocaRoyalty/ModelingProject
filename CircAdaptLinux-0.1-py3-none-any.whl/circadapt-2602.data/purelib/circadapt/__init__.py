"""
@package CircAdapt.

CircAdapt is a modelling framework of the cardiovascular system.
The framework is written in C++ and this package is a wrapper to use
CircAdapt in python. The default CircAdapt is empty. The other class
descriptions automatically build the corresponding model.
"""

import platform
import os
import pathlib

# %% Default path
DEFAULT_PATH_TO_CIRCADAPT = ""
"""
Default path to CircAdapt.dll.

Do not change this unless you develop the c++ code.
By default, it points to the compiled dll file in the package.
"""

# Add extension to default path
if platform.system() == 'Windows':
    DEFAULT_PATH_TO_CIRCADAPT = 'CircAdaptLib.dll'
elif platform.system() == 'Linux':
    DEFAULT_PATH_TO_CIRCADAPT = 'libCircAdaptLib.so'
elif platform.system() == 'Darwin':
    DEFAULT_PATH_TO_CIRCADAPT = 'libCircAdaptLib.dylib'

def get_default_path_to_circadapt():
    """
    Get the path to the CircAdapt library.
    
    For development, looks in CircAdapt_Library build folder first.
    Falls back to bundled library in package directory.
    """
    # Check for CIRCADAPT_LIBRARY_PATH environment variable (user override)
    if 'CIRCADAPT_LIBRARY_PATH' in os.environ:
        return os.environ['CIRCADAPT_LIBRARY_PATH']
    
    # Check for development build in sibling CircAdapt_Library folder
    package_dir = pathlib.Path(__file__).parent
    project_root = package_dir.parent.parent.parent  # src/circadapt -> src -> pyCircAdapt -> parent
    circadapt_lib_dir = project_root / "CircAdapt_Library" / "build"
   
    if circadapt_lib_dir.exists():
        # Look in build folder for compiled library
        if platform.system() == 'Windows':
            dev_lib = circadapt_lib_dir / "Release" / "CircAdaptLib.dll"
        elif platform.system() == 'Linux':
            dev_lib = circadapt_lib_dir / "libCircAdaptLib.so"
        elif platform.system() == 'Darwin':
            dev_lib = circadapt_lib_dir / "Release" / "libCircAdaptLib.dylib"
        else:
            dev_lib = None
        
        if dev_lib and dev_lib.exists():
            return str(dev_lib)
        
        
    
    # Fall back to bundled library in package
    return DEFAULT_PATH_TO_CIRCADAPT


# %% define for documentation
class CircAdapt:
    pass

# %% import structures
from circadapt.error import ModelCrashed, TriggerNotFound, CorruptBuild

# Import version from installed package metadata (set by setup.py)
try:
    from importlib.metadata import version
    __version__ = version("CircAdapt")
except Exception:
    __version__ = "0.0.0dev"

from circadapt.circadapt import CircAdapt, load_plugin_components
from circadapt.model.vanosta2023 import VanOsta2023
from circadapt.model.vanosta2024 import VanOsta2024
